package com.bookrecommendation.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Model class representing a Book.
 */
public class Book {
    private final int id; // Added id
    private final String title;
    private final String author;
    private final String description;
    private int rating; // Rating from 1-5
    private final List<String> comments; // List of comments

    // Constructor with id
    public Book(int id, String title, String author, String description) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.description = description;
        this.rating = 0; // Default rating
        this.comments = new ArrayList<>(); // Initialize comment list
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }
    
    public String getDescription() {
        return description;
    }

    public int getRating() {
        return rating;
    }

    // Setters
    public void setRating(int rating) {
        this.rating = rating;
    }

    // Comment methods
    public List<String> getComments() {
        return comments;
    }

    public void addComment(String comment) {
        comments.add(comment);
    }

    @Override
    public String toString() {
        return title; // Only display the title in the list
    }
}
