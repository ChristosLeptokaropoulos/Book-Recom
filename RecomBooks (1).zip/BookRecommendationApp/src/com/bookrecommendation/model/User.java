package com.bookrecommendation.model;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

/**
 * Model class representing a User.
 */
public class User {
    private int id; // Added id
    private final String username;
    private final String email;
    private final String passwordHash; // Securely store the password hash

    // Constructor with id
    public User(int id, String username, String email, String passwordHash) {
        this.id = id;
        this.username = username;
        this.email = email;
        this.passwordHash = passwordHash;
    }

    // Constructor without id (for new users)
    public User(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.passwordHash = hashPassword(password);
    }

    // Getters
    public int getId() {
        return id;
    }

    public void setId(int id) { // Setter for id
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    // Password hashing method
    private String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(password.getBytes());
            return Base64.getEncoder().encodeToString(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Error initializing password hashing algorithm.", e);
        }
    }

    // Method to verify password
    public boolean verifyPassword(String password) {
        return this.passwordHash.equals(hashPassword(password));
    }
}
