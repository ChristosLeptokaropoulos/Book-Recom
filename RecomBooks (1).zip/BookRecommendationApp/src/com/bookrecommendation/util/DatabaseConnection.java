package com.bookrecommendation.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Utility class for managing database connections.
 */
public class DatabaseConnection {
    private static final String DATABASE_URL = "jdbc:postgresql://localhost:5432/book_recommendation";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "!2#4%6&8Qwertyu";

    private static Connection connection = null;

    /**
     * Retrieves a connection to the database.
     * 
     * @return A Connection object to the database.
     * @throws SQLException if a database access error occurs.
     */
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            // Establish a new connection
            connection = DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
        }
        return connection;
    }
}
