package com.bookrecommendation.util;

import javax.swing.*;

/**
 * Utility class to simulate sending verification emails.
 */
public class EmailUtil {
    public static void sendVerificationEmail(String email, String verificationCode) {
        // Simulate sending an email by showing a message dialog
        String message = "Verification code sent to " + email + ":\n" + verificationCode;
        JOptionPane.showMessageDialog(null, message, "Email Verification", JOptionPane.INFORMATION_MESSAGE);
    }
}
