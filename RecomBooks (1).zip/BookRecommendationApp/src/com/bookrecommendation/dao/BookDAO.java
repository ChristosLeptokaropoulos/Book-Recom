package com.bookrecommendation.dao;

import com.bookrecommendation.model.Book;
import com.bookrecommendation.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object for Book-related database operations.
 */
public class BookDAO {

    // Retrieves books associated with a specific mood
    public List<Book> getBooksByMood(String moodName) {
        List<Book> books = new ArrayList<>();
        String query = "SELECT b.id, b.title, b.author, b.description, b.rating " +
                "FROM books b " +
                "JOIN book_moods bm ON b.id = bm.book_id " +
                "JOIN moods m ON bm.mood_id = m.id " +
                "WHERE m.name = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, moodName);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    // Create Book object
                    int id = rs.getInt("id");
                    String title = rs.getString("title");
                    String author = rs.getString("author");
                    String description = rs.getString("description");
                    int rating = rs.getInt("rating");
                    Book book = new Book(id, title, author, description);
                    book.setRating(rating);

                    // Load comments for the book
                    List<String> comments = getBookComments(id);
                    book.getComments().addAll(comments);

                    books.add(book);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }

        return books;
    }

    // Updates the rating of a book
    public void updateBookRating(int bookId, int rating) {
        String query = "UPDATE books SET rating = ? WHERE id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, rating);
            pstmt.setInt(2, bookId);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
    }

    // Retrieves comments for a specific book
    public List<String> getBookComments(int bookId) {
        List<String> comments = new ArrayList<>();
        String query = "SELECT comment FROM comments WHERE book_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, bookId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    comments.add(rs.getString("comment"));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
        return comments;
    }

    // Adds a comment to a book
    public void addBookComment(int bookId, String comment) {
        String query = "INSERT INTO comments (book_id, comment) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, bookId);
            pstmt.setString(2, comment);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
}
