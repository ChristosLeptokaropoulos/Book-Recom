package com.bookrecommendation.dao;

import com.bookrecommendation.model.User;
import com.bookrecommendation.util.DatabaseConnection;

import java.sql.*;

/**
 * Data Access Object for User-related database operations.
 */
public class UserDAO {
    // Retrieves a user by email
    public User getUserByEmail(String email) {
        String query = "SELECT id, username, email, password_hash FROM users WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, email);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt("id");
                    String username = rs.getString("username");
                    String passwordHash = rs.getString("password_hash");
                    return new User(id, username, email, passwordHash);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
        return null;
    }

    // Retrieves a user by username
    public User getUserByUsername(String username) {
        String query = "SELECT id, username, email, password_hash FROM users WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int id = rs.getInt("id");
                    String uname = rs.getString("username");
                    String email = rs.getString("email");
                    String passwordHash = rs.getString("password_hash");
                    return new User(id, uname, email, passwordHash);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
        return null;
    }

    // Adds a new user to the database
    public void addUser(User user) {
        String query = "INSERT INTO users (username, email, password_hash) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getEmail());
            pstmt.setString(3, user.getPasswordHash());
            pstmt.executeUpdate();

            // Retrieve the generated user ID
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    user.setId(generatedKeys.getInt(1));
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
            // Handle exception
        }
    }
}
