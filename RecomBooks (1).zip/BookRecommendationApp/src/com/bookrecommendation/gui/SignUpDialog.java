package com.bookrecommendation.gui;

import com.bookrecommendation.dao.UserDAO;
import com.bookrecommendation.model.User;
import com.bookrecommendation.util.EmailUtil;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Random;

/**
 * Dialog window for user sign-up.
 */
public class SignUpDialog extends JDialog {
    private final JTextField usernameField;
    private final JTextField emailField;
    private final JPasswordField passwordField;
    private final JButton signUpButton;
    private String verificationCode;

    public SignUpDialog(JFrame parent) {
        super(parent, "Sign Up", true);
        setSize(400, 250);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 0, 20));

        // Input fields
        inputPanel.add(new JLabel("Username:"));
        usernameField = new JTextField();
        inputPanel.add(usernameField);

        inputPanel.add(new JLabel("Email:"));
        emailField = new JTextField();
        inputPanel.add(emailField);

        inputPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        inputPanel.add(passwordField);

        // Sign-up button
        signUpButton = new JButton("Sign Up");
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(signUpButton);

        add(inputPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        signUpButton.addActionListener(this::handleSignUp);
        setVisible(true);
    }

    private void handleSignUp(ActionEvent e) {
        String username = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();

        if (username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required.");
            return;
        }

        // Check if user already exists
        UserDAO userDAO = new UserDAO();
        User existingUser = userDAO.getUserByEmail(email);
        if (existingUser != null) {
            JOptionPane.showMessageDialog(this, "Email is already registered.");
            return;
        }

        // Generate verification code
        verificationCode = String.format("%06d", new Random().nextInt(999999));

        // Send verification email
        EmailUtil.sendVerificationEmail(email, verificationCode);

        // Prompt for verification code
        String enteredCode = JOptionPane.showInputDialog(this, "Enter the verification code sent to your email:");

        if (verificationCode.equals(enteredCode)) {
            JOptionPane.showMessageDialog(this, "Verification successful!");

            // Create User object
            User user = new User(username, email, password);
            // Add user to database
            userDAO.addUser(user);

            // Pass the user back to MainFrame
            ((MainFrame) getParent()).setCurrentUser(user);

            dispose();
        } else {
            JOptionPane.showMessageDialog(this, "Verification failed. Please try again.");
        }
    }
}
