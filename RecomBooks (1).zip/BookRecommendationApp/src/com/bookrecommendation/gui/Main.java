package com.bookrecommendation.gui;

import javax.swing.*;

/**
 * Main class of the application responsible for launching the GUI
 * and setting the system's appearance.
 */
public class Main {
    // Application messages
    private static final String ERROR_MESSAGE = "System appearance could not be set.\nThe application will use default styling.";
    private static final String ERROR_TITLE = "Appearance Warning";

    public static void main(String[] args) {
        // Start the GUI on the Event Dispatch Thread for thread safety
        SwingUtilities.invokeLater(() -> initializeApplication());
    }

    // Method to initialize the application
    private static void initializeApplication() {
        try {
            setSystemLookAndFeel();
            enableFontAntialiasing();
            createAndShowMainFrame();
        } catch (Exception e) {
            handleLookAndFeelError(e);
            createAndShowMainFrame();
        }
    }

    // Method to set the system's look and feel
    private static void setSystemLookAndFeel() throws Exception {
        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }

    // Method to enable font antialiasing
    private static void enableFontAntialiasing() {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
    }

    // Method to create and show the main window
    private static void createAndShowMainFrame() {
        MainFrame mainFrame = new MainFrame();
        mainFrame.setLocationRelativeTo(null);
        mainFrame.setVisible(true);
    }

    // Method to handle look and feel errors
    private static void handleLookAndFeelError(Exception e) {
        String errorMessage = "Failed to set system look and feel: " + e.getMessage();
        System.err.println(errorMessage);

        JOptionPane.showMessageDialog(null,
                ERROR_MESSAGE,
                ERROR_TITLE,
                JOptionPane.WARNING_MESSAGE);
    }
}
